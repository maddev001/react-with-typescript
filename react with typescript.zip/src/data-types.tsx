export interface Todo {
  id?: number | null;
  todo: string;
  isDone: boolean;
}
